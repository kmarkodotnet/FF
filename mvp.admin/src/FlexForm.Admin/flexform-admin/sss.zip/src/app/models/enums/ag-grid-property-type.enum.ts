export enum AgGridPropertyType{
    Constant,
    CheckBox,
    Number,
    Text,
    DropDown
}