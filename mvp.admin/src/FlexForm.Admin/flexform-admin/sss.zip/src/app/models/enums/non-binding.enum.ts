export enum NonBinding {
    Panel = 0,
    Icon = 1,	
    Link = 2,
    Button = 4,
    Label = 5,
    Breadcrumb = 6
}
