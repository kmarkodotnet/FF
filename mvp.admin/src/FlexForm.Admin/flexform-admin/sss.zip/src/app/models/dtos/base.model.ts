export class Base<T>{
    id: T;
}