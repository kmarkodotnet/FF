import { BaseProperty } from "../properties";

export interface UiPropertiesInterface{
    uiProperties:BaseProperty<any>[];
}