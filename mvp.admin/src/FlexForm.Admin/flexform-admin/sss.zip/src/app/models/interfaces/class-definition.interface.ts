export interface IClassDefinition{
}