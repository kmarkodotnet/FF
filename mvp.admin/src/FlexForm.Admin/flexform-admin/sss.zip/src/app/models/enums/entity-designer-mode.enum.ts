export enum EntityDesignerMode {
    View = 0,
    Modify = 1,
    Clone = 2,
    New = 3
}
