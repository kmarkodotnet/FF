import { EntityEditorUiField } from './entity-editor-ui-field.model';

export class SimpleUiField extends EntityEditorUiField{
}