export enum VerticalAlignment {
    Top = 0,
    Middle = 1,
    Buttom = 2,
}
