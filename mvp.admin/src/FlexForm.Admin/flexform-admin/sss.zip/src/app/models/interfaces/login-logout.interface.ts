export interface ILoginLogout{
    init();
    login();
    logout();
}