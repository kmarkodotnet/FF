import { BaseProperty } from '../properties/base-property.model';

export interface IViewDefinition{
    uiProperties:BaseProperty<any>[];
}