export enum FormType {
    Edit = 0,
    List = 1,
    View = 2
}
