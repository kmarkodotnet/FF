export class BaseUiField{
    name: string;
    color: string;
}