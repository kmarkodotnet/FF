import { Base } from "./base.model";

export class BaseWithTimeStamp<T> extends Base<T>{
    timestamp:any;
}