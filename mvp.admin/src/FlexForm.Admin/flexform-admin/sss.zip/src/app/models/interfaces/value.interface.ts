export interface IValue{
}