import { IForm } from './form.interface';
import { FormControl, FieldDefinition } from '../../../models/dtos';
import { FieldValue } from '../../../models/dtos/field-value.model';

export interface INonBindingForm extends IForm{
}