export class AppSettings {

    public static FRONTEND_URL = location.protocol + '//' + location.hostname + ':4200/';
    public static FRONTEND_PROD_URL = location.protocol + '//' + location.hostname + '/';

    public static API_ENDPOINT = location.protocol + '//' + location.hostname + ':54856/api/v1/';
}
